package types;

import java.util.HashMap;
import ast.*;

public class TypeChecker implements CommandVisitor {
    
    private HashMap<Command, Type> typeMap;
    private StringBuffer errorBuffer;

    /* Useful error strings:
     *
     * "Function " + func.name() + " has a void argument in position " + pos + "."
     * "Function " + func.name() + " has an error in argument in position " + pos + ": " + error.getMessage()
     *
     * "Function main has invalid signature."
     *
     * "Not all paths in function " + currentFunctionName + " have a return."
     *

     *
     * "Function " + currentFunctionName + " returns " + currentReturnType + " not " + retType + "."
     *

     */

    public TypeChecker()
    {
        typeMap = new HashMap<Command, Type>();
        errorBuffer = new StringBuffer();
    }

    private void reportError(int lineNum, int charPos, String message)
    {
        errorBuffer.append("TypeError(" + lineNum + "," + charPos + ")");
        errorBuffer.append("[" + message + "]" + "\n");
    }

    private void put(Command node, Type type)
    {
        if (type instanceof ErrorType) {
            reportError(node.lineNumber(), node.charPosition(), ((ErrorType)type).getMessage());
        }
        typeMap.put(node, type);
    }
    
    public Type getType(Command node)
    {
        return typeMap.get(node);
    }
    
    public boolean check(Command ast)
    {
        ast.accept(this);
        return !hasError();
    }
    
    public boolean hasError()
    {
        return errorBuffer.length() != 0;
    }
    
    public String errorReport()
    {
        return errorBuffer.toString();
    }

    @Override
    public void visit(ExpressionList node) {
    	put(node, new VoidType());
    }

    @Override
    public void visit(DeclarationList node) {
    	node.forEach(x -> 
    	{
    		x.accept(this);
    	});
    }

    @Override
    public void visit(StatementList node) {
    	put(node, new VoidType());
    }

    @Override
    public void visit(AddressOf node) {
    	put(node, node.symbol().type());
    }

    @Override
    public void visit(LiteralBool node) {
    	put(node, new BoolType());
    }

    @Override
    public void visit(LiteralFloat node) {
    	put(node, new FloatType());
    }

    @Override
    public void visit(LiteralInt node) {
    	put(node, new IntType());
    }

    @Override
    public void visit(VariableDeclaration node) {
    	if(node.symbol().type() instanceof ErrorType)
    	{
    		put(node, new ErrorType("Variable " + node.symbol().name() + " has invalid type " + node.symbol().type() + "."));
    	}
    	else
    	{
        	put(node, node.symbol().type());

    	}
    }

    @Override
    public void visit(ArrayDeclaration node) {
    	if(node.symbol().type() instanceof ErrorType)
    	{
    		put(node, new ErrorType("Array " + node.symbol().name() + " has invalid base type " + node.symbol().type() + "."));
    	}
    	else
    	{
        	put(node, node.symbol().type());

    	}
    }
    @Override
    public void visit(FunctionDefinition node) {
        if (node.symbol().name().equals("main") && !(node.symbol().type() instanceof VoidType))
        {
        	put(node, new ErrorType("Function main has invalid signature."));
        }
        else
        {
        	put(node, node.symbol().type());	
        }
    }

    @Override
    public void visit(Comparison node) {
    	put(node, new BoolType());
    }
    
    @Override
    public void visit(Addition node) {
    	put(node, getType((Command)node.leftSide()).add(getType((Command)node.rightSide())));
    }
    
    @Override
    public void visit(Subtraction node) {
    	put(node, getType((Command)node.leftSide()).sub(getType((Command)node.rightSide())));
    }
    
    @Override
    public void visit(Multiplication node) {
    	put(node, getType((Command)node.leftSide()).mul(getType((Command)node.rightSide())));
    }
    
    @Override
    public void visit(Division node) {
    	put(node, getType((Command)node.leftSide()).div(getType((Command)node.rightSide())));
    }
    
    @Override
    public void visit(LogicalAnd node) {
    	put(node, getType((Command)node.leftSide()).and(getType((Command)node.rightSide())));
    }

    @Override
    public void visit(LogicalOr node) {
    	put(node, getType((Command)node.leftSide()).or(getType((Command)node.rightSide())));
    }

    @Override
    public void visit(LogicalNot node) {
    	put(node, getType((Command)node.expression()));
    }
    
    @Override
    public void visit(Dereference node) {
    	put(node, getType((Command)node.expression()));
    }

    @Override
    public void visit(Index node) {
    	
    }

    @Override
    public void visit(Assignment node) {
    	put(node, getType((Command)node.destination()).assign(getType((Command)node.source())));
    }

    @Override
    public void visit(Call node) {
    	
    }

    @Override
    public void visit(IfElseBranch node) {
    	if (getType((Command)node.condition()).equivalent(new BoolType()))
    	{
    		put(node, new VoidType());
    	}
    	else
    	{
    		put(node, new ErrorType("IfElseBranch requires bool condition not " + getType((Command)node.condition()) + "."));
    	}
    }
    
    @Override
    public void visit(WhileLoop node) {
    	if (getType((Command)node.condition()).equivalent(new BoolType()))
    	{
    		put(node, new VoidType());
    	}
    	else
    	{
    		put(node, new ErrorType("WhileLoop requires bool condition not " + getType((Command)node.condition()) + "."));
    	}
    }

    @Override
    public void visit(Return node) {
    	put(node, getType(node));
    }
    
    @Override
    public void visit(ReadSymbol node) {
    	put(node, node.symbol().type());
    }

    @Override
    public void visit(ast.Error node) {
        put(node, new ErrorType(node.message()));
    }
}
